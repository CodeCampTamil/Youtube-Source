from flask import Flask, render_template, request, redirect, url_for
from models import db, Details
from flask_migrate import Migrate

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:1234@localhost/flask_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
migrate = Migrate(app, db)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/details/add', methods=['GET', 'POST'])
def details_add():

    if request.method == 'POST':

        new_detail = Details(name = request.form['user_name'], age = request.form['age'])
        db.session.add(new_detail)
        db.session.commit()

        return redirect(url_for('details_list'))

    return render_template('details_add.html')

@app.route('/details/list')
def details_list():

    all_details = Details.query.all()

    return render_template('details_list.html', details=all_details)

@app.route('/details/edit/<int:id>', methods=['GET', 'POST'])
def details_edit(id):
    
    data = Details.query.get(id)

    if request.method == 'POST':

       data.name = request.form['user_name'] 
       data.age = request.form['age'] 

       db.session.commit()

       return redirect(url_for('details_list'))

    return render_template('details_edit.html', details=data)

@app.route('/details/delete/<int:id>')
def details_delete(id):

    data = Details.query.get(id)
    db.session.delete(data)
    db.session.commit()

    return redirect(url_for('details_list'))

if __name__ == '__main__':
    app.run(debug=True)