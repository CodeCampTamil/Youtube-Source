# Flask-Series

# Follow the steps to run the project

STEP 1: Open the terminal and navigate to the project directory

STEP 2: Create virtual environment
```bash
python -m venv venv
```

STEP 3: Activate the virtual environment
```bash
# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

STEP 4: Install the dependencies
```bash
pip install -r requirements.txt
```

STEP 5: Create database in the name flask_db in mysql and run the following commands
```bash
flask db init
flask db migrate
flask db upgrade
```

STEP 6: Run the application
```bash
python app.py   (or) flask run
```

STEP 7: Open the application in your browser
```
http://[IP_ADDRESS]
```
